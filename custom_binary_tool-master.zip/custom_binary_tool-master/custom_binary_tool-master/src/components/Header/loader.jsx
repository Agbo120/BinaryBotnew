import React from 'react';
import ContentLoader from 'react-content-loader';

// [Todo] Needs a better design for Loader
const Loader = () => (
    <ContentLoader>
        <rect x='80' y='17' rx='4' ry='4' width='300' height='23' />
    </ContentLoader>
);

export default Loader;
