import Tour from './tour.jsx';
import TourTargets from './tour-targets.jsx';

export { TourTargets };
export default Tour;
