import Footer from './Footer.jsx';

export default Footer;
