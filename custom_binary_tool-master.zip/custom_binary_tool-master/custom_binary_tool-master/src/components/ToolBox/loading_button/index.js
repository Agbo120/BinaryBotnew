import LoadingButton from './loading_button.jsx';

export default LoadingButton;
