import MessagePage from './message-page.jsx';

export default MessagePage;
