import Main from './main.jsx';

export default Main;
