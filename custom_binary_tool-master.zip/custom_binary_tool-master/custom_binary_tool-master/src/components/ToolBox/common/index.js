const SAVE_LOAD_TYPE = {
    local: 'local',
    google_drive: 'google-drive',
};

export default SAVE_LOAD_TYPE;
